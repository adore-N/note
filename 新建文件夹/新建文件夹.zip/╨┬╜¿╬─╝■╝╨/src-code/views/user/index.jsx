import React, { Component } from 'react';

export default class extends Component {
  render () {
    return (
      <div className="box">
        <header className = "header"></header>
        <div className = "content">user</div>
      </div>
    )
  }
}