import React, { Component } from 'react';
export default class extends Component {
  componentDidMount () {
  }
  render () {
    return (
      <div className="box">
        <header className = "header"></header>
        <div className = "content">cart</div>
      </div>
    )
  }
}