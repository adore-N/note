import React, { Component } from 'react';
export default class extends Component {
  render () {
    return (
      <div className="box">
        <header className = "header"></header>
        <div className = "content">
        分类
        </div>
      </div>
    )
  }
}